"""
配置管理（通过环境变量或 .env 文件注入）
"""

from typing import List

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )

    # ── Vault 连接 ──────────────────────────────────────────────────
    VAULT_ADDR: str = "http://127.0.0.1:8200"
    VAULT_TOKEN: str = "root"                   # 管理用 token（有权限创建/吊销 orphan token）
    VAULT_TLS_VERIFY: bool = True               # 生产环境务必保持 True

    # ── Orphan Token 配置 ───────────────────────────────────────────
    VAULT_ORPHAN_TOKEN_ACCESSOR: str = ""       # 当前在用 orphan token 的 accessor（rotate 后更新）
    VAULT_ORPHAN_TOKEN_ROLE: str = ""           # 可选：token role 名称
    VAULT_TOKEN_TTL: str = "720h"              # 新 token 的 TTL（30 天）
    VAULT_TOKEN_POLICIES: List[str] = ["default"]  # 新 token 的 policies

    # ── 应用 ────────────────────────────────────────────────────────
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000
    LOG_LEVEL: str = "INFO"

    @field_validator("VAULT_TOKEN_POLICIES", mode="before")
    @classmethod
    def parse_policies(cls, v):
        if isinstance(v, str):
            return [p.strip() for p in v.split(",") if p.strip()]
        return v


settings = Settings()
