"""
Vault Client
封装与 HashiCorp Vault 的所有交互逻辑
"""

import logging
from typing import Optional

import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class VaultClient:
    """HashiCorp Vault HTTP 客户端"""

    def __init__(self):
        self.vault_addr = settings.VAULT_ADDR
        self.vault_token = settings.VAULT_TOKEN  # 用于认证的根/管理 token
        self.orphan_token_accessor = settings.VAULT_ORPHAN_TOKEN_ACCESSOR
        self.orphan_token_role = settings.VAULT_ORPHAN_TOKEN_ROLE
        self.headers = {
            "X-Vault-Token": self.vault_token,
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        path: str,
        payload: Optional[dict] = None,
    ) -> dict:
        url = f"{self.vault_addr}/v1/{path.lstrip('/')}"
        async with httpx.AsyncClient(verify=settings.VAULT_TLS_VERIFY) as client:
            response = await client.request(
                method,
                url,
                headers=self.headers,
                json=payload,
                timeout=30,
            )
            response.raise_for_status()
            # 204 No Content → return empty dict
            if response.status_code == 204:
                return {}
            return response.json()

    # ── Token 操作 ─────────────────────────────────────────────────

    async def create_orphan_token(self) -> dict:
        """
        创建新的 orphan token。
        如果配置了 role，则使用 role 创建（推荐）；否则使用通用接口。
        """
        if self.orphan_token_role:
            path = f"auth/token/create/{self.orphan_token_role}"
        else:
            path = "auth/token/create-orphan"

        payload = {
            "display_name": "rotated-orphan-token",
            "no_parent": True,           # 确保为 orphan
            "renewable": True,
            "ttl": settings.VAULT_TOKEN_TTL,
            "policies": settings.VAULT_TOKEN_POLICIES,
        }
        logger.info("Creating new orphan token via: %s", path)
        data = await self._request("POST", path, payload)
        return data.get("auth", {})

    async def revoke_token_by_accessor(self, accessor: str) -> None:
        """通过 accessor 吊销旧 token（无需持有旧 token 本身）"""
        logger.info("Revoking old token with accessor: %s", accessor)
        await self._request(
            "POST",
            "auth/token/revoke-accessor",
            {"accessor": accessor},
        )

    async def lookup_token_by_accessor(self, accessor: str) -> dict:
        """查询 token 信息（用于验证新 token）"""
        data = await self._request(
            "POST",
            "auth/token/lookup-accessor",
            {"accessor": accessor},
        )
        return data.get("data", {})

    # ── 主流程 ─────────────────────────────────────────────────────

    async def rotate_orphan_token(self) -> dict:
        """
        完整的 rotate 流程：
        1. 创建新的 orphan token
        2. 吊销旧 token（如果配置了旧 accessor）
        3. 返回新 token 信息（供后续持久化）

        ⚠️  生产建议：
            - 新 token 创建成功后，将新 accessor 写入配置中心/Secret Manager，
              再吊销旧 token，避免服务中断。
        """
        logger.info("=== Starting Vault orphan token rotation ===")

        # Step 1: 创建新 token
        new_auth = await self.create_orphan_token()
        new_token = new_auth.get("client_token")
        new_accessor = new_auth.get("accessor")
        logger.info("New token created. Accessor: %s", new_accessor)

        # Step 2: 吊销旧 token
        old_accessor = self.orphan_token_accessor
        if old_accessor and old_accessor != new_accessor:
            try:
                await self.revoke_token_by_accessor(old_accessor)
                logger.info("Old token revoked successfully.")
            except httpx.HTTPStatusError as exc:
                # 旧 token 可能已过期，不影响主流程
                logger.warning("Failed to revoke old token (may already be expired): %s", exc)
        else:
            logger.info("No old accessor configured, skipping revocation.")

        # Step 3: 返回结果
        result = {
            "new_accessor": new_accessor,
            "new_token": new_token,   # ⚠️  生产中应立即写入 Secret Manager，不要日志打印
            "lease_duration": new_auth.get("lease_duration"),
            "policies": new_auth.get("policies", []),
            "renewable": new_auth.get("renewable"),
        }

        logger.info(
            "=== Rotation complete. New accessor: %s | TTL: %ss ===",
            new_accessor,
            new_auth.get("lease_duration"),
        )
        return result
