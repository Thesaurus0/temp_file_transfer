"""
定时任务入口
由 APScheduler 在指定时间自动调用
"""

import logging

from app.vault_client import VaultClient

logger = logging.getLogger(__name__)


async def rotate_vault_orphan_token() -> None:
    """
    定时任务主函数：rotate Vault orphan token
    - 每周一 08:00
    - 每周五 10:00
    """
    logger.info(">>> [Scheduled] rotate_vault_orphan_token triggered")
    try:
        client = VaultClient()
        result = await client.rotate_orphan_token()
        logger.info(
            ">>> [Scheduled] Rotation succeeded. New accessor: %s",
            result.get("new_accessor"),
        )
        # TODO: 将 result["new_token"] / result["new_accessor"] 写入
        #       你的配置中心（AWS Secrets Manager / K8s Secret / Consul 等）
    except Exception as exc:
        # 定时任务中捕获所有异常，避免 scheduler 静默退出
        logger.error(">>> [Scheduled] Rotation FAILED: %s", exc, exc_info=True)
        # TODO: 接入告警（钉钉/PagerDuty/Slack 等）
