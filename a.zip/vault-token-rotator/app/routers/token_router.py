"""
Token 管理 API 路由
"""

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from app.schemas import ErrorResponse, RotateResponse
from app.vault_client import VaultClient

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post(
    "/token/rotate",
    response_model=RotateResponse,
    responses={
        200: {"model": RotateResponse, "description": "Rotate 成功"},
        500: {"model": ErrorResponse, "description": "Rotate 失败"},
    },
    summary="手动触发 Vault Orphan Token Rotate",
    description=(
        "立即执行一次 Vault orphan token 轮换：\n\n"
        "1. 向 Vault 申请一个新的 orphan token\n"
        "2. 使用旧 token 的 accessor 吊销旧 token\n"
        "3. 返回新 token 信息（accessor、TTL、policies）\n\n"
        "> ⚠️ **注意**：返回的 `new_accessor` 需写入配置中心，以便下次 rotate 时吊销该 token。"
    ),
)
async def rotate_token() -> RotateResponse:
    triggered_at = datetime.now(timezone.utc)
    try:
        client = VaultClient()
        result = await client.rotate_orphan_token()
        return RotateResponse(
            success=True,
            message="Vault orphan token rotated successfully.",
            triggered_at=triggered_at,
            new_accessor=result.get("new_accessor"),
            policies=result.get("policies"),
            lease_duration=result.get("lease_duration"),
            renewable=result.get("renewable"),
        )
    except Exception as exc:
        logger.error("Manual rotate failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                success=False,
                message="Failed to rotate Vault orphan token.",
                detail=str(exc),
            ).model_dump(),
        )


@router.get(
    "/token/jobs",
    summary="查看定时任务状态",
    description="返回所有已注册的定时任务及下次执行时间。",
)
async def list_jobs():
    """查看定时任务配置"""
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from app.main import scheduler

    jobs = [
        {
            "id": job.id,
            "name": job.name,
            "next_run_time": str(job.next_run_time),
            "trigger": str(job.trigger),
        }
        for job in scheduler.get_jobs()
    ]
    return {"jobs": jobs}
