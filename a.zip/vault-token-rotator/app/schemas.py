"""
API 数据模型
"""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class RotateResponse(BaseModel):
    success: bool = Field(..., description="是否成功")
    message: str = Field(..., description="执行结果说明")
    triggered_at: datetime = Field(..., description="触发时间（UTC）")
    new_accessor: Optional[str] = Field(None, description="新 token 的 accessor")
    policies: Optional[List[str]] = Field(None, description="新 token 的 policies")
    lease_duration: Optional[int] = Field(None, description="新 token TTL（秒）")
    renewable: Optional[bool] = Field(None, description="是否可续约")

    model_config = {
        "json_schema_extra": {
            "example": {
                "success": True,
                "message": "Vault orphan token rotated successfully.",
                "triggered_at": "2024-06-10T08:00:00Z",
                "new_accessor": "abc123-accessor",
                "policies": ["default", "app-policy"],
                "lease_duration": 2592000,
                "renewable": True,
            }
        }
    }


class ErrorResponse(BaseModel):
    success: bool = False
    message: str
    detail: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "success": False,
                "message": "Failed to rotate Vault orphan token.",
                "detail": "connection refused: http://127.0.0.1:8200",
            }
        }
    }
