"""
Vault Orphan Token Rotator
- 定时任务：每周一 08:00 和每周五 10:00 自动执行
- Swagger API：可随时手动触发 rotate
"""

import logging
from contextlib import asynccontextmanager

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import FastAPI

from app.routers import token_router
from app.scheduler import rotate_vault_orphan_token

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler(timezone="Asia/Tokyo")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── 启动时注册定时任务 ──────────────────────────────────────────
    # 每周一 08:00
    scheduler.add_job(
        rotate_vault_orphan_token,
        trigger=CronTrigger(day_of_week="mon", hour=8, minute=0),
        id="rotate_monday",
        name="Rotate Vault Token - Every Monday 08:00",
        replace_existing=True,
    )
    # 每周五 10:00
    scheduler.add_job(
        rotate_vault_orphan_token,
        trigger=CronTrigger(day_of_week="fri", hour=10, minute=0),
        id="rotate_friday",
        name="Rotate Vault Token - Every Friday 10:00",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("Scheduler started. Registered jobs:")
    for job in scheduler.get_jobs():
        logger.info("  • [%s] %s | next run: %s", job.id, job.name, job.next_run_time)

    yield  # ── 应用运行中 ──────────────────────────────────────────

    scheduler.shutdown(wait=False)
    logger.info("Scheduler stopped.")


app = FastAPI(
    title="Vault Orphan Token Rotator",
    description=(
        "## Vault Orphan Token 自动轮换服务\n\n"
        "### 定时任务\n"
        "| 触发时间 | 说明 |\n"
        "|----------|------|\n"
        "| 每周一 08:00 | 自动 rotate orphan token |\n"
        "| 每周五 10:00 | 自动 rotate orphan token |\n\n"
        "### 手动触发\n"
        "使用 `POST /api/v1/token/rotate` 可随时手动执行轮换。"
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(token_router.router, prefix="/api/v1", tags=["Token Management"])


@app.get("/health", tags=["Health"])
async def health_check():
    """服务健康检查"""
    jobs = [
        {
            "id": job.id,
            "name": job.name,
            "next_run_time": str(job.next_run_time),
        }
        for job in scheduler.get_jobs()
    ]
    return {"status": "ok", "scheduled_jobs": jobs}
