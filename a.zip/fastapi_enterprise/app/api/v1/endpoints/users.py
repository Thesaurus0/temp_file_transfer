import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.api.deps import CurrentUser, DbSession, SuperUser
from app.common.pagination import PagedResponse, PaginationParams
from app.schemas.user import UserChangePassword, UserCreate, UserOut, UserUpdate
from app.services.user_service import UserService

router = APIRouter()


@router.post("/", response_model=UserOut, status_code=status.HTTP_201_CREATED, summary="注册用户")
async def create_user(data: UserCreate, db: DbSession):
    service = UserService(db)
    user = await service.create_user(data)
    return user


@router.get("/me", response_model=UserOut, summary="获取当前用户信息")
async def get_me(current_user: CurrentUser):
    return current_user


@router.patch("/me", response_model=UserOut, summary="更新当前用户信息")
async def update_me(data: UserUpdate, current_user: CurrentUser, db: DbSession):
    service = UserService(db)
    return await service.update_user(current_user.id, data)


@router.post("/me/change-password", status_code=status.HTTP_204_NO_CONTENT, summary="修改密码")
async def change_password(data: UserChangePassword, current_user: CurrentUser, db: DbSession):
    service = UserService(db)
    await service.change_password(current_user.id, data.old_password, data.new_password)


# ── Admin only ────────────────────────────────────────────────────────────────

@router.get("/", response_model=PagedResponse[UserOut], summary="[Admin] 用户列表")
async def list_users(
    pagination: Annotated[PaginationParams, Depends()],
    db: DbSession,
    _: SuperUser,   # 仅验证权限，不使用
):
    service = UserService(db)
    items, total = await service.list_users(page=pagination.page, page_size=pagination.page_size)
    return PagedResponse.create(items=items, total=total, params=pagination)


@router.get("/{user_id}", response_model=UserOut, summary="[Admin] 获取用户详情")
async def get_user(user_id: uuid.UUID, db: DbSession, _: SuperUser):
    service = UserService(db)
    return await service.get_user(user_id)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT, summary="[Admin] 删除用户")
async def delete_user(user_id: uuid.UUID, db: DbSession, _: SuperUser):
    service = UserService(db)
    await service.delete_user(user_id)
