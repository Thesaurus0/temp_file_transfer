from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel

from app.api.deps import DbSession
from app.core.security import create_access_token, create_refresh_token
from app.services.user_service import UserService

router = APIRouter()


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


@router.post("/login", response_model=TokenResponse, summary="用户登录")
async def login(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
    db: DbSession,
):
    """
    使用 email + password 登录，返回 JWT。
    username 字段填邮箱。
    """
    service = UserService(db)
    user = await service.authenticate(email=form_data.username, password=form_data.password)
    return TokenResponse(
        access_token=create_access_token(user.id),
        refresh_token=create_refresh_token(user.id),
    )
