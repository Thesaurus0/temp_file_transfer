import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


# ── Base ──────────────────────────────────────────────────────────────────────

class UserBase(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
    full_name: str | None = Field(None, max_length=100)


# ── Request schemas ───────────────────────────────────────────────────────────

class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=100)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not any(c.isupper() for c in v):
            raise ValueError("密码必须包含至少一个大写字母")
        if not any(c.isdigit() for c in v):
            raise ValueError("密码必须包含至少一个数字")
        return v


class UserUpdate(BaseModel):
    full_name: str | None = Field(None, max_length=100)
    email: EmailStr | None = None


class UserChangePassword(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=8)


# ── Response schemas ──────────────────────────────────────────────────────────

class UserOut(UserBase):
    model_config = ConfigDict(from_attributes=True)  # 允许从 ORM 对象直接转换

    id: uuid.UUID
    is_active: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime


class UserList(BaseModel):
    items: list[UserOut]
    total: int
    page: int
    page_size: int
