from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Project root: app/core/config.py -> up 3 levels -> project root
BASE_DIR = Path(__file__).resolve().parent.parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        # .env 不存在时不报错（生产环境用系统环境变量）
        env_file_override=False,
    )

    # ── Application ──────────────────────────────────────────────
    app_name: str = "Enterprise App"
    app_env: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    secret_key: str
    allowed_hosts: list[AnyHttpUrl] = []

    # ── Database ─────────────────────────────────────────────────
    database_url: str
    database_pool_size: int = 10
    database_max_overflow: int = 20
    database_echo: bool = False       # SQL 日志，debug 时开启

    # ── Redis ────────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"

    # ── JWT ──────────────────────────────────────────────────────
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # ── Logging ──────────────────────────────────────────────────
    log_level: str = "INFO"
    log_json: bool = False            # 生产环境输出 JSON 日志

    # ── Sentry ───────────────────────────────────────────────────
    sentry_dsn: str | None = None

    # ── Computed properties ───────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_development(self) -> bool:
        return self.app_env == "development"

    @field_validator("database_echo", mode="before")
    @classmethod
    def set_db_echo(cls, v: bool, info) -> bool:
        # 生产环境强制关闭 SQL 日志
        if info.data.get("app_env") == "production":
            return False
        return v


@lru_cache
def get_settings() -> Settings:
    """
    用 lru_cache 缓存，整个进程只初始化一次。
    测试时可用 get_settings.cache_clear() 重置。
    """
    return Settings()
