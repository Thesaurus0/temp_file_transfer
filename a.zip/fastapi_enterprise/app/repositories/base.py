from typing import Any, Generic, TypeVar
from uuid import UUID

from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import Base

ModelT = TypeVar("ModelT", bound=Base)


class BaseRepository(Generic[ModelT]):
    """
    通用异步 Repository。
    子类只需指定 model 即可获得标准 CRUD。

    用法：
        class UserRepository(BaseRepository[User]):
            model = User
    """

    model: type[ModelT]

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    # ── Read ──────────────────────────────────────────────────────

    async def get(self, id: UUID) -> ModelT | None:
        return await self.db.get(self.model, id)

    async def get_or_raise(self, id: UUID) -> ModelT:
        obj = await self.get(id)
        if obj is None:
            raise ValueError(f"{self.model.__name__} {id} not found")
        return obj

    async def list(
        self,
        *,
        offset: int = 0,
        limit: int = 20,
        filters: list | None = None,
        order_by: list | None = None,
    ) -> tuple[list[ModelT], int]:
        """返回 (items, total)，方便分页"""
        stmt = select(self.model)

        if filters:
            stmt = stmt.where(*filters)
        if order_by:
            stmt = stmt.order_by(*order_by)

        # total count（复用相同 filters）
        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await self.db.execute(count_stmt)).scalar_one()

        stmt = stmt.offset(offset).limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all()), total

    async def exists(self, *filters) -> bool:
        stmt = select(func.count()).select_from(self.model).where(*filters)
        count = (await self.db.execute(stmt)).scalar_one()
        return count > 0

    # ── Write ─────────────────────────────────────────────────────

    async def create(self, obj: ModelT) -> ModelT:
        self.db.add(obj)
        await self.db.flush()    # 获取 DB 生成的字段（如 id），但不 commit
        await self.db.refresh(obj)
        return obj

    async def update(self, obj: ModelT, data: dict[str, Any]) -> ModelT:
        for key, value in data.items():
            setattr(obj, key, value)
        await self.db.flush()
        await self.db.refresh(obj)
        return obj

    async def delete(self, obj: ModelT) -> None:
        await self.db.delete(obj)
        await self.db.flush()

    # ── Helpers ───────────────────────────────────────────────────

    async def execute(self, stmt: Select) -> Any:
        """执行自定义查询"""
        return await self.db.execute(stmt)
