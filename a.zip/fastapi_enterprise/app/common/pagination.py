from typing import Any, Generic, TypeVar

from fastapi import Query
from pydantic import BaseModel

T = TypeVar("T")


# ── Pagination ────────────────────────────────────────────────────────────────

class PaginationParams(BaseModel):
    """作为 FastAPI 依赖注入使用"""
    page: int = Query(default=1, ge=1, description="页码，从 1 开始")
    page_size: int = Query(default=20, ge=1, le=100, description="每页数量，最大 100")

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


class PagedResponse(BaseModel, Generic[T]):
    """分页响应包装器"""
    items: list[T]
    total: int
    page: int
    page_size: int
    total_pages: int

    @classmethod
    def create(
        cls,
        items: list[T],
        total: int,
        params: PaginationParams,
    ) -> "PagedResponse[T]":
        return cls(
            items=items,
            total=total,
            page=params.page,
            page_size=params.page_size,
            total_pages=(total + params.page_size - 1) // params.page_size,
        )


# ── Standard response ─────────────────────────────────────────────────────────

class ApiResponse(BaseModel, Generic[T]):
    """统一响应格式"""
    success: bool = True
    data: T | None = None
    message: str = "ok"

    @classmethod
    def ok(cls, data: T, message: str = "ok") -> "ApiResponse[T]":
        return cls(success=True, data=data, message=message)

    @classmethod
    def empty(cls, message: str = "ok") -> "ApiResponse[None]":
        return cls(success=True, data=None, message=message)
