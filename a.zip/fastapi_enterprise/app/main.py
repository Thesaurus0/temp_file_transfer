import sentry_sdk
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.api.v1.router import router as v1_router
from app.common.exceptions import register_exception_handlers
from app.core.config import get_settings
from app.core.logging import setup_logging

settings = get_settings()

# ── Logging ───────────────────────────────────────────────────────────────────
setup_logging()

# ── Sentry（生产监控）─────────────────────────────────────────────────────────
if settings.sentry_dsn and settings.is_production:
    sentry_sdk.init(dsn=settings.sentry_dsn, traces_sample_rate=0.1)

# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.app_name,
    debug=settings.debug,
    # 生产环境关闭 docs，避免暴露 API 结构
    docs_url="/docs" if not settings.is_production else None,
    redoc_url="/redoc" if not settings.is_production else None,
    openapi_url="/openapi.json" if not settings.is_production else None,
)

# ── Middleware ────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[str(h) for h in settings.allowed_hosts],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# ── Exception handlers ────────────────────────────────────────────────────────
register_exception_handlers(app)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(v1_router)


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"], include_in_schema=False)
async def health():
    return {"status": "ok", "env": settings.app_env}
