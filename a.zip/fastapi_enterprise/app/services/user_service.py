import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.common.exceptions import ConflictError, NotFoundError, UnauthorizedError
from app.core.security import hash_password, verify_password
from app.models.user import User
from app.repositories.user_repo import UserRepository
from app.schemas.user import UserCreate, UserUpdate


class UserService:
    """
    业务逻辑层。
    - 不知道 HTTP / FastAPI 的存在
    - 不直接操作 DB，通过 Repository
    - 可以单独做单元测试（mock Repository）
    """

    def __init__(self, db: AsyncSession) -> None:
        self.repo = UserRepository(db)

    async def create_user(self, data: UserCreate) -> User:
        # 检查邮箱唯一性
        if await self.repo.get_by_email(data.email):
            raise ConflictError(f"邮箱 {data.email} 已被注册")

        # 检查用户名唯一性
        if await self.repo.get_by_username(data.username):
            raise ConflictError(f"用户名 {data.username} 已被占用")

        user = User(
            email=data.email,
            username=data.username,
            full_name=data.full_name,
            hashed_password=hash_password(data.password),
        )
        return await self.repo.create(user)

    async def get_user(self, user_id: uuid.UUID) -> User:
        user = await self.repo.get(user_id)
        if not user:
            raise NotFoundError(f"用户 {user_id} 不存在")
        return user

    async def list_users(self, *, page: int = 1, page_size: int = 20):
        offset = (page - 1) * page_size
        items, total = await self.repo.get_active_users(offset=offset, limit=page_size)
        return items, total

    async def update_user(self, user_id: uuid.UUID, data: UserUpdate) -> User:
        user = await self.get_user(user_id)

        # 邮箱变更时检查唯一性
        if data.email and data.email != user.email:
            if await self.repo.get_by_email(data.email):
                raise ConflictError(f"邮箱 {data.email} 已被使用")

        update_data = data.model_dump(exclude_unset=True)
        return await self.repo.update(user, update_data)

    async def change_password(
        self, user_id: uuid.UUID, old_password: str, new_password: str
    ) -> None:
        user = await self.get_user(user_id)

        if not verify_password(old_password, user.hashed_password):
            raise UnauthorizedError("原密码错误")

        await self.repo.update(user, {"hashed_password": hash_password(new_password)})

    async def delete_user(self, user_id: uuid.UUID) -> None:
        user = await self.get_user(user_id)
        await self.repo.delete(user)

    async def authenticate(self, email: str, password: str) -> User:
        user = await self.repo.get_by_email(email)
        if not user or not verify_password(password, user.hashed_password):
            raise UnauthorizedError("邮箱或密码错误")
        if not user.is_active:
            raise UnauthorizedError("账号已被禁用")
        return user
