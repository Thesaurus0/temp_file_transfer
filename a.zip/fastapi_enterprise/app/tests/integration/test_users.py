import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_create_user(client: AsyncClient):
    response = await client.post("/api/v1/users/", json={
        "email": "test@example.com",
        "username": "testuser",
        "password": "SecurePass1",
    })
    assert response.status_code == 201
    data = response.json()
    assert data["email"] == "test@example.com"
    assert "hashed_password" not in data     # 不能泄露密码


@pytest.mark.asyncio
async def test_duplicate_email(client: AsyncClient):
    payload = {"email": "dup@example.com", "username": "user1", "password": "SecurePass1"}
    await client.post("/api/v1/users/", json=payload)

    payload["username"] = "user2"
    response = await client.post("/api/v1/users/", json=payload)
    assert response.status_code == 409


@pytest.mark.asyncio
async def test_login(client: AsyncClient):
    await client.post("/api/v1/users/", json={
        "email": "login@example.com",
        "username": "loginuser",
        "password": "SecurePass1",
    })
    response = await client.post(
        "/api/v1/auth/login",
        data={"username": "login@example.com", "password": "SecurePass1"},
    )
    assert response.status_code == 200
    assert "access_token" in response.json()
