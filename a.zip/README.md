# Enterprise App — Python FastAPI 模板

企业级 Python 后端模板，包含数据库 CRUD、定时任务、结构化日志、JWT 认证等完整能力。

## 技术栈

| 层次 | 技术 |
|------|------|
| Web 框架 | FastAPI + Uvicorn |
| 数据库 ORM | SQLAlchemy 2.0（async） |
| 数据迁移 | Alembic |
| 数据校验 | Pydantic v2 |
| 定时任务 | APScheduler |
| 日志 | structlog（console / JSON） |
| 认证 | JWT（python-jose）+ bcrypt |
| 测试 | pytest-asyncio + httpx |

## 项目结构

```
enterprise_app/
├── app/
│   ├── api/
│   │   ├── deps.py              # 依赖注入（当前用户 / 权限）
│   │   ├── middleware.py        # RequestID、AccessLog、异常处理
│   │   └── v1/endpoints/        # REST 路由（Auth / Users / Items）
│   ├── core/
│   │   ├── config.py            # 分层配置（.env / 环境变量）
│   │   ├── exceptions.py        # 自定义异常体系
│   │   ├── logging.py           # structlog 初始化
│   │   └── security.py          # JWT + bcrypt
│   ├── db/
│   │   └── session.py           # 异步引擎 + get_db 依赖
│   ├── models/                  # SQLAlchemy ORM 模型
│   ├── repositories/
│   │   ├── base.py              # 泛型 BaseRepository[T]（CRUD）
│   │   └── __init__.py          # UserRepository / ItemRepository
│   ├── schemas/                 # Pydantic Request / Response Schema
│   ├── services/                # 业务逻辑层
│   ├── tasks/
│   │   └── scheduler.py         # APScheduler 定时任务
│   └── main.py                  # FastAPI 入口（lifespan）
├── tests/
│   ├── conftest.py              # pytest fixtures（内存 DB）
│   ├── integration/             # HTTP 集成测试
│   └── unit/                   # Service 单元测试
├── alembic/                     # DB 迁移脚本
├── .env                         # 默认配置
├── docker-compose.yml
├── Dockerfile
└── requirements.txt
```

## 快速开始

### 本地开发（SQLite）

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 启动（开发环境自动创建 SQLite 表）
uvicorn app.main:app --reload

# 3. 查看 API 文档
open http://localhost:8000/docs
```

### Docker Compose（PostgreSQL）

```bash
docker-compose up -d
```

## 数据库迁移（Alembic）

```bash
# 生成迁移文件
alembic revision --autogenerate -m "init"

# 执行迁移
alembic upgrade head

# 回滚
alembic downgrade -1
```

## 测试

```bash
# 运行全部测试（含覆盖率）
pytest

# 只跑单元测试
pytest tests/unit/

# 只跑集成测试
pytest tests/integration/
```

## 分层架构说明

```
HTTP 请求
  └─► Router（参数解析）
        └─► Service（业务逻辑 / 事务）
              └─► Repository（数据访问）
                    └─► SQLAlchemy（DB）
```

- **Router** 只做参数解析和 Schema 转换，不含业务逻辑
- **Service** 是事务边界，跨 Repository 协调
- **Repository** 只做 SQL，不含业务判断
- **Schema** 严格区分 Create / Update / Response（不共用）

## 定时任务

编辑 `app/tasks/scheduler.py`，在 `register_jobs()` 中添加：

```python
# Cron 触发（每天 03:00）
scheduler.add_job(my_job, CronTrigger(hour=3, minute=0), id="my_job")

# Interval 触发（每 10 分钟）
scheduler.add_job(my_job, IntervalTrigger(minutes=10), id="my_job")
```

## 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `APP_ENV` | `development` | `development` / `production` |
| `DATABASE_URL` | SQLite | 数据库连接串 |
| `SECRET_KEY` | `changeme` | JWT 签名密钥（生产必须修改） |
| `LOG_FORMAT` | `console` | `console` / `json` |
| `LOG_LEVEL` | `DEBUG` | 日志级别 |

## 生产部署注意事项

1. `SECRET_KEY` 必须替换为随机长字符串
2. `DATABASE_URL` 改为 PostgreSQL
3. `LOG_FORMAT=json` 适配日志收集系统
4. 使用 Alembic 管理迁移，不要用 `create_all`
5. 可通过 `.env.production` 覆盖生产专属配置
